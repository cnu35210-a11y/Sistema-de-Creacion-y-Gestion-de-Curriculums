module com.creadorcv {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires com.google.gson;

    opens com.creadorcv             to javafx.fxml;
    opens com.creadorcv.controlador to javafx.fxml;
    opens com.creadorcv.vista       to javafx.fxml;
    opens com.creadorcv.modelo      to com.google.gson;

    exports com.creadorcv;
    exports com.creadorcv.modelo;
    exports com.creadorcv.persistencia;
    exports com.creadorcv.controlador;
}
