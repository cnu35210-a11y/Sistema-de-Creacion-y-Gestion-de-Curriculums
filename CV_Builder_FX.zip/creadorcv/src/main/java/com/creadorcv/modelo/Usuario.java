package com.creadorcv.modelo;

/** Cuenta de usuario local: nombre de usuario y contraseña ya cifrada (hash). */
public class Usuario {
    private String usuario;
    private String passwordHash;

    public Usuario() {}

    public Usuario(String usuario, String passwordHash) {
        this.usuario = usuario;
        this.passwordHash = passwordHash;
    }

    public String getUsuario()                  { return usuario; }
    public String getPasswordHash()              { return passwordHash; }
    public void   setUsuario(String u)           { this.usuario = u; }
    public void   setPasswordHash(String h)      { this.passwordHash = h; }
}
