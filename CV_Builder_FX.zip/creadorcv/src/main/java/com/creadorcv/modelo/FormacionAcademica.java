package com.creadorcv.modelo;

public class FormacionAcademica {
    private String institucion;
    private String titulo;
    private String estado;   // Graduado / En curso / Incompleto
    private String periodoInicio;
    private String periodoFin;

    public FormacionAcademica() {}

    public FormacionAcademica(String institucion, String titulo,
                              String estado, String periodoInicio, String periodoFin) {
        this.institucion   = institucion;
        this.titulo        = titulo;
        this.estado        = estado;
        this.periodoInicio = periodoInicio;
        this.periodoFin    = periodoFin;
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getInstitucion()   { return institucion; }
    public String getTitulo()        { return titulo; }
    public String getEstado()        { return estado; }
    public String getPeriodoInicio() { return periodoInicio; }
    public String getPeriodoFin()    { return periodoFin; }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setInstitucion(String institucion)     { this.institucion = institucion; }
    public void setTitulo(String titulo)               { this.titulo = titulo; }
    public void setEstado(String estado)               { this.estado = estado; }
    public void setPeriodoInicio(String periodoInicio) { this.periodoInicio = periodoInicio; }
    public void setPeriodoFin(String periodoFin)       { this.periodoFin = periodoFin; }

    @Override
    public String toString() {
        return titulo + " — " + institucion;
    }
}
