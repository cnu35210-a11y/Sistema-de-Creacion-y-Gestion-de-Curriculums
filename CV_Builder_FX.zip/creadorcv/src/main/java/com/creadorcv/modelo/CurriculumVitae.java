package com.creadorcv.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Raíz del modelo de datos.
 * Contiene todos los bloques del CV y la plantilla seleccionada.
 */
public class CurriculumVitae {

    private DatosPersonales           datosPersonales;
    private List<ExperienciaLaboral>  experiencias;
    private List<FormacionAcademica>  formaciones;
    private List<Capacitacion>        capacitaciones;
    private List<Habilidad>           habilidades;
    private List<Idioma>              idiomas;
    private String                    plantilla;  // "CLASICO" | "ATS" | "FOTO"

    public CurriculumVitae() {
        datosPersonales = new DatosPersonales();
        experiencias    = new ArrayList<>();
        formaciones     = new ArrayList<>();
        capacitaciones  = new ArrayList<>();
        habilidades     = new ArrayList<>();
        idiomas         = new ArrayList<>();
        plantilla       = "CLASICO";
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public DatosPersonales          getDatosPersonales() { return datosPersonales; }
    public List<ExperienciaLaboral> getExperiencias()    { return experiencias; }
    public List<FormacionAcademica> getFormaciones()     { return formaciones; }
    public List<Capacitacion>       getCapacitaciones()  { return capacitaciones; }
    public List<Habilidad>          getHabilidades()     { return habilidades; }
    public List<Idioma>             getIdiomas()         { return idiomas; }
    public String                   getPlantilla()       { return plantilla; }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setDatosPersonales(DatosPersonales dp)         { this.datosPersonales = dp; }
    public void setExperiencias(List<ExperienciaLaboral> list) { this.experiencias = list; }
    public void setFormaciones(List<FormacionAcademica> list)  { this.formaciones = list; }
    public void setCapacitaciones(List<Capacitacion> list)     { this.capacitaciones = list; }
    public void setHabilidades(List<Habilidad> list)           { this.habilidades = list; }
    public void setIdiomas(List<Idioma> list)                  { this.idiomas = list; }
    public void setPlantilla(String plantilla)                 { this.plantilla = plantilla; }
}
