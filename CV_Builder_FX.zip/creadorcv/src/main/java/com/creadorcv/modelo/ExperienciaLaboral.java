package com.creadorcv.modelo;

public class ExperienciaLaboral {
    private String empresa;
    private String puesto;
    private String fechaInicio;
    private String fechaFin;
    private boolean trabajoActual;
    private String logros;

    public ExperienciaLaboral() {}

    public ExperienciaLaboral(String empresa, String puesto,
                              String fechaInicio, String fechaFin,
                              boolean trabajoActual, String logros) {
        this.empresa = empresa;
        this.puesto = puesto;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.trabajoActual = trabajoActual;
        this.logros = logros;
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getEmpresa()      { return empresa; }
    public String getPuesto()       { return puesto; }
    public String getFechaInicio()  { return fechaInicio; }
    public String getFechaFin()     { return fechaFin; }
    public boolean isTrabajoActual(){ return trabajoActual; }
    public String getLogros()       { return logros; }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setEmpresa(String empresa)           { this.empresa = empresa; }
    public void setPuesto(String puesto)             { this.puesto = puesto; }
    public void setFechaInicio(String fechaInicio)   { this.fechaInicio = fechaInicio; }
    public void setFechaFin(String fechaFin)         { this.fechaFin = fechaFin; }
    public void setTrabajoActual(boolean v)          { this.trabajoActual = v; }
    public void setLogros(String logros)             { this.logros = logros; }

    @Override
    public String toString() {
        return puesto + " — " + empresa;
    }
}
