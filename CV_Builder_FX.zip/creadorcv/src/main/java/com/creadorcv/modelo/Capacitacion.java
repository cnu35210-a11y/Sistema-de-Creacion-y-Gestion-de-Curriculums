package com.creadorcv.modelo;

/** Curso o capacitación complementaria: nombre + institución que lo dictó. */
public class Capacitacion {
    private String nombre;
    private String institucion;

    public Capacitacion() {}

    public Capacitacion(String nombre, String institucion) {
        this.nombre = nombre;
        this.institucion = institucion;
    }

    public String getNombre()                { return nombre; }
    public String getInstitucion()            { return institucion; }
    public void   setNombre(String n)         { this.nombre = n; }
    public void   setInstitucion(String i)    { this.institucion = i; }

    @Override
    public String toString() {
        return institucion != null && !institucion.isEmpty()
                ? nombre + " (" + institucion + ")" : nombre;
    }
}
