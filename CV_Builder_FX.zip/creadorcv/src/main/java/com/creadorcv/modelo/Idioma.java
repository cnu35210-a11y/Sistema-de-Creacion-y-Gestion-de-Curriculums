package com.creadorcv.modelo;

public class Idioma {
    private String nombre;
    private String nivel;   // A1 / A2 / B1 / B2 / C1 / C2 / Nativo

    public Idioma() {}

    public Idioma(String nombre, String nivel) {
        this.nombre = nombre;
        this.nivel  = nivel;
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getNombre() { return nombre; }
    public String getNivel()  { return nivel;  }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setNivel(String nivel)   { this.nivel  = nivel;  }

    @Override
    public String toString() {
        return nombre + " – " + nivel;
    }
}
