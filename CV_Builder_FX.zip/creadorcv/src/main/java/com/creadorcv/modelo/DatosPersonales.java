package com.creadorcv.modelo;

public class DatosPersonales {
    private String nombre;
    private String apellido;
    private String correo;
    private String telefono;
    private String direccion;
    private String enlaceProfesional;   // LinkedIn / GitHub
    private String perfilProfesional;   // Resumen / objetivo
    private String fotoBase64;          // Foto de perfil codificada en Base64
    private String fotoMimeType;        // "image/jpeg" | "image/png" | "image/gif"

    public DatosPersonales() {}

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getNombre()            { return nombre; }
    public String getApellido()          { return apellido; }
    public String getCorreo()            { return correo; }
    public String getTelefono()          { return telefono; }
    public String getDireccion()         { return direccion; }
    public String getEnlaceProfesional() { return enlaceProfesional; }
    public String getPerfilProfesional() { return perfilProfesional; }
    public String getFotoBase64()        { return fotoBase64; }
    public String getFotoMimeType()      { return fotoMimeType; }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setNombre(String nombre)                       { this.nombre = nombre; }
    public void setApellido(String apellido)                   { this.apellido = apellido; }
    public void setCorreo(String correo)                       { this.correo = correo; }
    public void setTelefono(String telefono)                   { this.telefono = telefono; }
    public void setDireccion(String direccion)                 { this.direccion = direccion; }
    public void setEnlaceProfesional(String enlaceProfesional) { this.enlaceProfesional = enlaceProfesional; }
    public void setPerfilProfesional(String perfilProfesional) { this.perfilProfesional = perfilProfesional; }
    public void setFotoBase64(String fotoBase64)               { this.fotoBase64 = fotoBase64; }
    public void setFotoMimeType(String fotoMimeType)           { this.fotoMimeType = fotoMimeType; }

    /** Devuelve el data URI listo para usar en HTML/CSS, o null si no hay foto. */
    public String getFotoDataURI() {
        if (fotoBase64 == null || fotoBase64.isEmpty()) return null;
        String mime = (fotoMimeType != null && !fotoMimeType.isEmpty()) ? fotoMimeType : "image/jpeg";
        return "data:" + mime + ";base64," + fotoBase64;
    }

    public String getNombreCompleto() {
        return (nombre != null ? nombre : "") + " " + (apellido != null ? apellido : "");
    }
}
