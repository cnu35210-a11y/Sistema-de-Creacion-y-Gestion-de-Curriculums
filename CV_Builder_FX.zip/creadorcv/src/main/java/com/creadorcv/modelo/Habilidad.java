package com.creadorcv.modelo;

/** Una habilidad simple: solo el nombre (sin tipo ni nivel). */
public class Habilidad {
    private String nombre;

    public Habilidad() {}

    public Habilidad(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre()            { return nombre; }
    public void   setNombre(String n)    { this.nombre = n; }

    @Override
    public String toString() { return nombre; }
}
