package com.creadorcv;

import com.creadorcv.controlador.Router;
import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("CV-Builder FX — Sistema de Creación y Gestión de Currículums");
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        Router.iniciar(stage);
        Router.ir("Login.fxml");
    }

    public static void main(String[] args) {
        launch();
    }
}
