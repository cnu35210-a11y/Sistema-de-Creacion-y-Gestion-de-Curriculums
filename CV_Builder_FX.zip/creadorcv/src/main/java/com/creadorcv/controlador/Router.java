package com.creadorcv.controlador;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

/**
 * Gestiona la navegación entre pantallas de la aplicación reemplazando la
 * raíz de la única {@link Stage} activa por el FXML solicitado.
 */
public final class Router {

    private static Stage stage;

    public static void iniciar(Stage stage) {
        Router.stage = stage;
    }

    /** Navega a la pantalla indicada (nombre de archivo dentro de /vista, ej. "Home.fxml"). */
    public static void ir(String fxml) {
        try {
            Parent root = FXMLLoader.load(Router.class.getResource("/com/creadorcv/vista/" + fxml));
            if (stage.getScene() == null) {
                stage.setScene(new Scene(root, 1200, 720));
            } else {
                stage.getScene().setRoot(root);
            }
            stage.show();
        } catch (Exception e) {
            // Antes solo se capturaba IOException: cualquier otro error (por ejemplo un
            // NullPointerException dentro del initialize() del controlador de destino)
            // se perdía en silencio y el botón parecía "no hacer nada". Ahora se registra
            // en consola y se muestra al usuario para poder diagnosticarlo.
            e.printStackTrace();
            mostrarErrorNavegacion(fxml, e);
        }
    }

    private static void mostrarErrorNavegacion(String fxml, Exception e) {
        Throwable causa = e.getCause() != null ? e.getCause() : e;
        Alert alerta = new Alert(AlertType.ERROR);
        alerta.setTitle("Error al abrir la pantalla");
        alerta.setHeaderText("No se pudo cargar \"" + fxml + "\"");
        alerta.setContentText(causa.getClass().getSimpleName() + ": " + causa.getMessage());
        alerta.showAndWait();
    }

    private Router() {}
}
