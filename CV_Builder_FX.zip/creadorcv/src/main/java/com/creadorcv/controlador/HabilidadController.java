package com.creadorcv.controlador;

import com.creadorcv.modelo.Habilidad;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador FXML del fragmento {@code PasoHabilidades.fxml}.
 * Gestiona directamente sus propios controles y toda la lógica del bloque
 * "Habilidades": solo el nombre de cada habilidad (sin tipo ni nivel),
 * configuración de tabla, alta y baja de registros.
 */
public class HabilidadController {

    @FXML private TextField txtHabilidad;
    @FXML private Button btnAgregarHab, btnEliminarHab;
    @FXML private TableView<Habilidad> tblHabilidades;
    @FXML private TableColumn<Habilidad, String> colHabilidad;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnAgregarHab.setOnAction(e -> agregar());
        btnEliminarHab.setOnAction(e -> eliminar());
    }

    public void configurarTabla() {
        colHabilidad.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNombre()));
        tblHabilidades.setItems(contexto.getListaHab());
    }

    public void agregar() {
        if (txtHabilidad.getText().trim().isEmpty()) { notificador.error("Ingresa el nombre de la habilidad."); return; }
        Habilidad h = new Habilidad(txtHabilidad.getText().trim());
        contexto.getListaHab().add(h);
        contexto.getCv().getHabilidades().add(h);
        txtHabilidad.clear();
        notificador.setStatus("✔ Habilidad agregada.");
        actualizarPreview.run();
    }

    public void eliminar() {
        Habilidad sel = tblHabilidades.getSelectionModel().getSelectedItem();
        if (sel == null) { notificador.error("Selecciona una habilidad para eliminar."); return; }
        contexto.getListaHab().remove(sel);
        contexto.getCv().getHabilidades().remove(sel);
        notificador.setStatus("Habilidad eliminada.");
        actualizarPreview.run();
    }
}
