package com.creadorcv.controlador;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;

import java.net.URL;
import java.util.ResourceBundle;

/** Controla la galería de plantillas: el usuario elige un diseño antes de llenar el formulario. */
public class PlantillasController implements Initializable {

    @FXML private ToggleButton tglClasico;
    @FXML private ToggleButton tglAts;
    @FXML private ToggleButton tglFoto;
    @FXML private Button btnContinuar;
    @FXML private Button btnVolver;

    private final ToggleGroup grupo = new ToggleGroup();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tglClasico.setToggleGroup(grupo);
        tglAts.setToggleGroup(grupo);
        tglFoto.setToggleGroup(grupo);
        tglClasico.setSelected(true);

        btnContinuar.setOnAction(e -> {
            Sesion.actual().getContexto().getCv().setPlantilla(codigoSeleccionado());
            Router.ir("Formulario.fxml");
        });

        btnVolver.setOnAction(e -> Router.ir("Home.fxml"));
    }

    private String codigoSeleccionado() {
        if (tglAts.isSelected())  return "ATS";
        if (tglFoto.isSelected()) return "FOTO";
        return "CLASICO";
    }
}
