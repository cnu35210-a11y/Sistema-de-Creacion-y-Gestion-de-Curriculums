package com.creadorcv.controlador;

import com.creadorcv.persistencia.GestorUsuarios;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** Controla la pantalla de acceso: inicio de sesión y registro de nuevos usuarios. */
public class LoginController implements Initializable {

    @FXML private Label        lblTitulo;
    @FXML private TextField    txtUsuario;
    @FXML private PasswordField txtPassword;
    @FXML private PasswordField txtConfirmar;
    @FXML private javafx.scene.layout.VBox cajaConfirmar;
    @FXML private Label        lblMensaje;
    @FXML private Button       btnAccion;
    @FXML private Hyperlink    linkCambiarModo;

    private boolean modoRegistro = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        actualizarModo();
        btnAccion.setOnAction(e -> confirmar());
        linkCambiarModo.setOnAction(e -> { modoRegistro = !modoRegistro; lblMensaje.setText(""); actualizarModo(); });
    }

    private void actualizarModo() {
        lblTitulo.setText(modoRegistro ? "Crear cuenta" : "Iniciar sesión");
        btnAccion.setText(modoRegistro ? "Registrarme" : "Iniciar sesión");
        linkCambiarModo.setText(modoRegistro ? "¿Ya tienes cuenta? Inicia sesión" : "¿No tienes cuenta? Regístrate");
        cajaConfirmar.setVisible(modoRegistro);
        cajaConfirmar.setManaged(modoRegistro);
    }

    private void confirmar() {
        String usuario = txtUsuario.getText().trim();
        String password = txtPassword.getText();

        if (usuario.isEmpty() || password.isEmpty()) {
            lblMensaje.setText("Completa usuario y contraseña.");
            return;
        }

        try {
            if (modoRegistro) {
                if (!password.equals(txtConfirmar.getText())) {
                    lblMensaje.setText("Las contraseñas no coinciden.");
                    return;
                }
                if (!GestorUsuarios.registrar(usuario, password)) {
                    lblMensaje.setText("Ese usuario ya existe.");
                    return;
                }
                entrar(usuario);
            } else {
                if (!GestorUsuarios.validar(usuario, password)) {
                    lblMensaje.setText("Usuario o contraseña incorrectos.");
                    return;
                }
                entrar(usuario);
            }
        } catch (IOException e) {
            lblMensaje.setText("Error al acceder a los datos de usuarios: " + e.getMessage());
        }
    }

    private void entrar(String usuario) {
        Sesion.actual().setUsuarioActual(usuario);
        Router.ir("Home.fxml");
    }
}
