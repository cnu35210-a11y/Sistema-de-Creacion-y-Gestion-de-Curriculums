package com.creadorcv.controlador;

import javafx.scene.control.Alert;
import javafx.scene.control.Label;

/**
 * Centraliza la forma en que se comunican mensajes de estado y errores
 * al usuario, para que ningún sub-controlador dependa directamente de
 * los detalles de cómo se muestran (Label de estado, Alert de error, etc.).
 */
public class NotificadorUI {

    private final Label lblStatus;

    public NotificadorUI(Label lblStatus) {
        this.lblStatus = lblStatus;
    }

    /** Muestra un mensaje informativo en la barra de estado inferior. */
    public void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }

    /** Muestra un diálogo de error bloqueante con el mensaje indicado. */
    public void error(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Error de validación");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
