package com.creadorcv.controlador;

import java.util.regex.Pattern;

/**
 * Métodos de utilidad estáticos compartidos por los distintos
 * sub-controladores (validaciones, formateo, etc.).
 */
public final class Utilidades {

    private Utilidades() {
        // Clase de utilidades: no instanciable.
    }

    /** Valida un correo electrónico. Un correo vacío se considera válido (campo opcional). */
    public static boolean validarCorreo(String correo) {
        if (correo == null || correo.trim().isEmpty()) return true;
        return Pattern.matches("^[\\w.+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$", correo.trim());
    }

    /** Devuelve el string dado o "" si es null, para evitar NullPointerException en la UI. */
    public static String orEmpty(String s) {
        return s != null ? s : "";
    }
}
