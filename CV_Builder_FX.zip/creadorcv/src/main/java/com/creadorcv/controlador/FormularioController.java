package com.creadorcv.controlador;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Orquesta el formulario por pasos: Datos personales → Experiencia →
 * Formación académica → Capacitación → Habilidades → Idiomas.
 * Al terminar el último paso navega a la Vista Previa.
 *
 * Cada paso vive en su propio fragmento FXML (carpeta {@code vista/pasos}),
 * incluido aquí mediante {@code fx:include}. JavaFX inyecta, por cada
 * include con {@code fx:id="pasoX"}, dos campos en este controlador: el nodo
 * raíz ({@code pasoX}) y el controlador del fragmento ({@code pasoXController}).
 * Ese controlador de fragmento (p. ej. {@link DatosPersonalesController}) ya
 * contiene tanto sus {@code @FXML} como toda su lógica de negocio; este
 * controlador padre solo lo inicializa y orquesta la navegación entre pasos.
 */
public class FormularioController implements Initializable {

    // ── Cabecera y navegación (definidos directamente en Formulario.fxml) ──
    @FXML private Label lblContexto, lblPaso;
    @FXML private Button btnAtras, btnSiguiente, btnCancelar;
    @FXML private HBox cajaIndicadorPasos;

    // ── Paso 0: Datos personales ──
    @FXML private Node pasoDatos;
    @FXML private DatosPersonalesController pasoDatosController;

    // ── Paso 1: Experiencia ──
    @FXML private Node pasoExperiencia;
    @FXML private ExperienciaController pasoExperienciaController;

    // ── Paso 2: Formación académica ──
    @FXML private Node pasoFormacion;
    @FXML private FormacionController pasoFormacionController;

    // ── Paso 3: Capacitación ──
    @FXML private Node pasoCapacitacion;
    @FXML private CapacitacionController pasoCapacitacionController;

    // ── Paso 4: Habilidades ──
    @FXML private Node pasoHabilidades;
    @FXML private HabilidadController pasoHabilidadesController;

    // ── Paso 5: Idiomas ──
    @FXML private Node pasoIdiomas;
    @FXML private IdiomaController pasoIdiomasController;

    private static final String[] NOMBRES_PASO = {
            "Datos Personales", "Experiencia Laboral", "Formación Académica",
            "Capacitación", "Habilidades", "Idiomas"
    };

    private final ContextoCV contexto = Sesion.actual().getContexto();
    private NotificadorUI notificador;

    private Node[] pasos;
    private int pasoActual = 0;
    private Circle[] puntosIndicador;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        notificador = new NotificadorUI(null);
        pasos = new Node[]{ pasoDatos, pasoExperiencia, pasoFormacion, pasoCapacitacion, pasoHabilidades, pasoIdiomas };

        inicializarSubControladores();
        configurarComponentes();
        cargarDatosExistentes();
        conectarEventos();
        construirIndicadorPasos();

        String archivo = Sesion.actual().getNombreArchivoActual();
        lblContexto.setText(archivo != null ? "Editando: " + archivo : "Nuevo Currículum");

        mostrarPaso(0);
    }

    /** Crea los puntos de progreso (uno por paso) que se muestran bajo el título del asistente. */
    private void construirIndicadorPasos() {
        puntosIndicador = new Circle[NOMBRES_PASO.length];
        cajaIndicadorPasos.getChildren().clear();
        for (int i = 0; i < NOMBRES_PASO.length; i++) {
            Circle punto = new Circle(5);
            punto.getStyleClass().add("wizard-dot");
            Tooltip.install(punto, new Tooltip(NOMBRES_PASO[i]));
            puntosIndicador[i] = punto;
            cajaIndicadorPasos.getChildren().add(punto);
        }
    }

    /** Actualiza el estilo de cada punto según sea el paso actual, un paso ya completado o uno pendiente. */
    private void actualizarIndicadorPasos(int indice) {
        for (int i = 0; i < puntosIndicador.length; i++) {
            puntosIndicador[i].getStyleClass().removeAll("wizard-dot-activo", "wizard-dot-hecho");
            if (i == indice) puntosIndicador[i].getStyleClass().add("wizard-dot-activo");
            else if (i < indice) puntosIndicador[i].getStyleClass().add("wizard-dot-hecho");
        }
    }

    /** Inyecta el contexto, notificador y callback de preview en cada controlador de paso. */
    private void inicializarSubControladores() {
        pasoDatosController.inicializar(contexto, notificador, this::sinAccion);
        pasoExperienciaController.inicializar(contexto, notificador, this::sinAccion);
        pasoFormacionController.inicializar(contexto, notificador, this::sinAccion);
        pasoCapacitacionController.inicializar(contexto, notificador, this::sinAccion);
        pasoHabilidadesController.inicializar(contexto, notificador, this::sinAccion);
        pasoIdiomasController.inicializar(contexto, notificador, this::sinAccion);
    }

    private void configurarComponentes() {
        pasoExperienciaController.configurarTabla();
        pasoExperienciaController.configurarListeners();
        pasoFormacionController.configurarTabla();
        pasoFormacionController.configurarCombo();
        pasoCapacitacionController.configurarTabla();
        pasoHabilidadesController.configurarTabla();
        pasoIdiomasController.configurarTabla();
        pasoIdiomasController.configurarCombo();
    }

    /** Cuando se abre un CV existente, precarga los campos de texto con sus datos. */
    private void cargarDatosExistentes() {
        if (Sesion.actual().getNombreArchivoActual() != null) {
            pasoDatosController.cargarDesdeCv();
        }
    }

    /** Los eventos de agregar/eliminar de cada paso ya se conectan dentro de su propio
     *  controlador (en {@code inicializar}); aquí solo queda la navegación entre pasos. */
    private void conectarEventos() {
        btnAtras.setOnAction(e -> { if (pasoActual > 0) mostrarPaso(pasoActual - 1); });
        btnSiguiente.setOnAction(e -> avanzar());
        btnCancelar.setOnAction(e -> Router.ir("Home.fxml"));
    }

    private void avanzar() {
        if (pasoActual == 0 && !pasoDatosController.guardarDatosPersonales()) return;
        if (pasoActual == pasos.length - 1) {
            Router.ir("VistaPrevia.fxml");
            return;
        }
        mostrarPaso(pasoActual + 1);
    }

    private void mostrarPaso(int indice) {
        pasoActual = indice;
        for (int i = 0; i < pasos.length; i++) {
            pasos[i].setVisible(i == indice);
            pasos[i].setManaged(i == indice);
        }
        lblPaso.setText("Paso " + (indice + 1) + " de " + pasos.length + ": " + NOMBRES_PASO[indice]);
        btnAtras.setDisable(indice == 0);
        btnSiguiente.setText(indice == pasos.length - 1 ? "Finalizar y Vista Previa" : "Siguiente");
        actualizarIndicadorPasos(indice);
    }

    /** Los sub-controladores llaman a esta callback tras cada cambio; el formulario no tiene vista previa en vivo. */
    private void sinAccion() { /* no-op: la vista previa se genera en la pantalla siguiente */ }
}
