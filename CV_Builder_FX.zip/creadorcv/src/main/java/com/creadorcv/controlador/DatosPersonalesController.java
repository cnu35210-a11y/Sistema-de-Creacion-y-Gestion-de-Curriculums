package com.creadorcv.controlador;

import com.creadorcv.modelo.DatosPersonales;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;

/**
 * Controlador FXML del fragmento {@code PasoDatosPersonales.fxml}.
 * Gestiona directamente sus propios controles (inyectados por JavaFX vía
 * {@code @FXML}) y toda la lógica de la sección "Datos Personales": los
 * campos de texto del formulario y la foto de perfil (selección,
 * eliminación, codificación en Base64 para su persistencia en el JSON).
 *
 * {@link FormularioController} lo obtiene como {@code pasoDatosController}
 * (inyección automática de {@code fx:include}) y lo inicializa llamando a
 * {@link #inicializar(ContextoCV, NotificadorUI, Runnable)}.
 */
public class DatosPersonalesController {

    @FXML private ImageView imgFotoPerfil;
    @FXML private Label lblFotoNombre;
    @FXML private TextField txtNombre, txtApellido, txtCorreo, txtTelefono, txtDireccion, txtEnlace;
    @FXML private TextArea txtPerfil;
    @FXML private Button btnSeleccionarFoto, btnEliminarFoto;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnSeleccionarFoto.setOnAction(e -> seleccionarFoto());
        btnEliminarFoto.setOnAction(e -> eliminarFoto());
    }

    public void seleccionarFoto() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Seleccionar foto de perfil");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                "Imagenes (*.jpg, *.jpeg, *.png, *.gif)", "*.jpg", "*.jpeg", "*.png", "*.gif"));
        File file = fc.showOpenDialog(ventanaActual());
        if (file == null) return;

        try {
            byte[] bytes = Files.readAllBytes(file.toPath());
            String base64 = Base64.getEncoder().encodeToString(bytes);

            String nombre = file.getName().toLowerCase();
            String mime;
            if (nombre.endsWith(".png"))       mime = "image/png";
            else if (nombre.endsWith(".gif"))  mime = "image/gif";
            else                               mime = "image/jpeg";

            contexto.getCv().getDatosPersonales().setFotoBase64(base64);
            contexto.getCv().getDatosPersonales().setFotoMimeType(mime);

            Image img = new Image(file.toURI().toString(), 120, 120, true, true);
            imgFotoPerfil.setImage(img);
            lblFotoNombre.setText(file.getName());
            notificador.setStatus("Foto cargada: " + file.getName());
            actualizarPreview.run();
        } catch (IOException e) {
            notificador.error("No se pudo cargar la imagen: " + e.getMessage());
        }
    }

    private Window ventanaActual() {
        return imgFotoPerfil.getScene() != null ? imgFotoPerfil.getScene().getWindow() : null;
    }

    public void eliminarFoto() {
        contexto.getCv().getDatosPersonales().setFotoBase64(null);
        contexto.getCv().getDatosPersonales().setFotoMimeType(null);
        imgFotoPerfil.setImage(null);
        lblFotoNombre.setText("Sin foto seleccionada");
        notificador.setStatus("Foto de perfil eliminada.");
        actualizarPreview.run();
    }

    /** Valida y guarda los datos personales. Devuelve true si son válidos y se guardaron. */
    public boolean guardarDatosPersonales() {
        if (txtNombre.getText().trim().isEmpty()) { notificador.error("El nombre es obligatorio."); return false; }
        if (!Utilidades.validarCorreo(txtCorreo.getText())) { notificador.error("Formato de correo inválido."); return false; }

        DatosPersonales dp = contexto.getCv().getDatosPersonales();
        dp.setNombre(txtNombre.getText().trim());
        dp.setApellido(txtApellido.getText().trim());
        dp.setCorreo(txtCorreo.getText().trim());
        dp.setTelefono(txtTelefono.getText().trim());
        dp.setDireccion(txtDireccion.getText().trim());
        dp.setEnlaceProfesional(txtEnlace.getText().trim());
        dp.setPerfilProfesional(txtPerfil.getText().trim());
        notificador.setStatus("Datos personales guardados.");
        actualizarPreview.run();
        return true;
    }

    /** Refresca los campos de texto y la foto a partir del CV actual del contexto compartido. */
    public void cargarDesdeCv() {
        DatosPersonales dp = contexto.getCv().getDatosPersonales();
        txtNombre.setText(Utilidades.orEmpty(dp.getNombre()));
        txtApellido.setText(Utilidades.orEmpty(dp.getApellido()));
        txtCorreo.setText(Utilidades.orEmpty(dp.getCorreo()));
        txtTelefono.setText(Utilidades.orEmpty(dp.getTelefono()));
        txtDireccion.setText(Utilidades.orEmpty(dp.getDireccion()));
        txtEnlace.setText(Utilidades.orEmpty(dp.getEnlaceProfesional()));
        txtPerfil.setText(Utilidades.orEmpty(dp.getPerfilProfesional()));

        if (dp.getFotoBase64() != null && !dp.getFotoBase64().isEmpty()) {
            try {
                byte[] bytes = Base64.getDecoder().decode(dp.getFotoBase64());
                Image img = new Image(new ByteArrayInputStream(bytes), 120, 120, true, true);
                imgFotoPerfil.setImage(img);
                lblFotoNombre.setText("Foto cargada");
            } catch (Exception ex) {
                imgFotoPerfil.setImage(null);
                lblFotoNombre.setText("Sin foto seleccionada");
            }
        } else {
            imgFotoPerfil.setImage(null);
            lblFotoNombre.setText("Sin foto seleccionada");
        }
    }

    /** Limpia todos los campos del formulario (usado por "Nuevo CV"). */
    public void limpiarCampos() {
        txtNombre.clear(); txtApellido.clear(); txtCorreo.clear();
        txtTelefono.clear(); txtDireccion.clear(); txtEnlace.clear(); txtPerfil.clear();
        imgFotoPerfil.setImage(null);
        lblFotoNombre.setText("Sin foto seleccionada");
    }
}
