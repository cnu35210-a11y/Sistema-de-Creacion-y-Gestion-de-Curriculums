package com.creadorcv.controlador;

import com.creadorcv.persistencia.MotorExportacion;

import javafx.scene.web.WebView;

/**
 * Gestiona la vista previa del CV (WebView), generando el HTML según la
 * plantilla ya guardada en el CV (elegida en la pantalla de Plantillas).
 */
public class PreviewController {

    private final ContextoCV contexto;
    private final WebView webPreview;

    public PreviewController(ContextoCV contexto, WebView webPreview) {
        this.contexto = contexto;
        this.webPreview = webPreview;
    }

    /** Regenera el HTML del CV actual y lo muestra en la vista previa. */
    public void actualizarPreview() {
        String html = MotorExportacion.generarHTML(contexto.getCv());
        webPreview.getEngine().loadContent(html, "text/html");
    }
}
