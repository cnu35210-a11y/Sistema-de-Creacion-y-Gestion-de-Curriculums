package com.creadorcv.controlador;

import com.creadorcv.modelo.Capacitacion;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador FXML del fragmento {@code PasoCapacitacion.fxml}.
 * Gestiona directamente sus propios controles y toda la lógica del bloque
 * "Capacitaciones": cursos o formación complementaria (nombre + institución),
 * configuración de tabla, alta y baja de registros.
 */
public class CapacitacionController {

    @FXML private TextField txtNombreCap, txtInstitucionCap;
    @FXML private Button btnAgregarCap, btnEliminarCap;
    @FXML private TableView<Capacitacion> tblCapacitaciones;
    @FXML private TableColumn<Capacitacion, String> colNombreCap, colInstitucionCap;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnAgregarCap.setOnAction(e -> agregar());
        btnEliminarCap.setOnAction(e -> eliminar());
    }

    public void configurarTabla() {
        colNombreCap.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNombre()));
        colInstitucionCap.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getInstitucion()));
        tblCapacitaciones.setItems(contexto.getListaCapacitacion());
    }

    public void agregar() {
        if (txtNombreCap.getText().trim().isEmpty()) {
            notificador.error("Ingresa el nombre de la capacitación o curso."); return;
        }
        Capacitacion c = new Capacitacion(
                txtNombreCap.getText().trim(), txtInstitucionCap.getText().trim());
        contexto.getListaCapacitacion().add(c);
        contexto.getCv().getCapacitaciones().add(c);
        txtNombreCap.clear();
        txtInstitucionCap.clear();
        notificador.setStatus("✔ Capacitación agregada.");
        actualizarPreview.run();
    }

    public void eliminar() {
        Capacitacion sel = tblCapacitaciones.getSelectionModel().getSelectedItem();
        if (sel == null) { notificador.error("Selecciona una capacitación para eliminar."); return; }
        contexto.getListaCapacitacion().remove(sel);
        contexto.getCv().getCapacitaciones().remove(sel);
        notificador.setStatus("Capacitación eliminada.");
        actualizarPreview.run();
    }
}
