package com.creadorcv.controlador;

import com.creadorcv.modelo.ExperienciaLaboral;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * Controlador FXML del fragmento {@code PasoExperiencia.fxml}.
 * Gestiona directamente sus propios controles y toda la lógica del bloque
 * "Experiencia Laboral": configuración de la tabla, alta y baja de registros.
 */
public class ExperienciaController {

    @FXML private TextField txtEmpresa, txtPuesto, txtFechaInicioExp, txtFechaFinExp;
    @FXML private CheckBox chkTrabajoActual;
    @FXML private TextArea txtLogros;
    @FXML private Button btnAgregarExp, btnEliminarExp;
    @FXML private TableView<ExperienciaLaboral> tblExperiencia;
    @FXML private TableColumn<ExperienciaLaboral, String> colPuesto, colEmpresa, colPeriodoExp;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnAgregarExp.setOnAction(e -> agregar());
        btnEliminarExp.setOnAction(e -> eliminar());
    }

    public void configurarTabla() {
        colPuesto.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getPuesto()));
        colEmpresa.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getEmpresa()));
        colPeriodoExp.setCellValueFactory(d -> {
            ExperienciaLaboral e = d.getValue();
            String periodo = e.getFechaInicio() + " – " + (e.isTrabajoActual() ? "Actualidad" : e.getFechaFin());
            return new SimpleStringProperty(periodo);
        });
        tblExperiencia.setItems(contexto.getListaExp());
    }

    /** Deshabilita la fecha de fin cuando se marca "Trabajo actual". */
    public void configurarListeners() {
        chkTrabajoActual.selectedProperty().addListener((o, ov, nv) ->
                txtFechaFinExp.setDisable(nv));
    }

    public void agregar() {
        if (txtEmpresa.getText().trim().isEmpty() || txtPuesto.getText().trim().isEmpty()) {
            notificador.error("Empresa y Puesto son obligatorios."); return;
        }
        if (txtFechaInicioExp.getText().trim().isEmpty()) {
            notificador.error("La fecha de inicio es obligatoria."); return;
        }
        ExperienciaLaboral exp = new ExperienciaLaboral(
                txtEmpresa.getText().trim(), txtPuesto.getText().trim(),
                txtFechaInicioExp.getText().trim(), txtFechaFinExp.getText().trim(),
                chkTrabajoActual.isSelected(), txtLogros.getText().trim());
        contexto.getListaExp().add(exp);
        contexto.getCv().getExperiencias().add(exp);
        limpiarFormulario();
        notificador.setStatus("✔ Experiencia agregada.");
        actualizarPreview.run();
    }

    public void eliminar() {
        ExperienciaLaboral sel = tblExperiencia.getSelectionModel().getSelectedItem();
        if (sel == null) { notificador.error("Selecciona una experiencia para eliminar."); return; }
        contexto.getListaExp().remove(sel);
        contexto.getCv().getExperiencias().remove(sel);
        notificador.setStatus("Experiencia eliminada.");
        actualizarPreview.run();
    }

    private void limpiarFormulario() {
        txtEmpresa.clear(); txtPuesto.clear();
        txtFechaInicioExp.clear(); txtFechaFinExp.clear();
        chkTrabajoActual.setSelected(false); txtLogros.clear();
    }
}
