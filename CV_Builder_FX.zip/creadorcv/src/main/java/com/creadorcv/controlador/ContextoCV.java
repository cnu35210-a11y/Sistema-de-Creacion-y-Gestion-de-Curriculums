package com.creadorcv.controlador;

import com.creadorcv.modelo.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Contenedor mutable del {@link CurriculumVitae} actualmente en edición y de
 * las listas observables que alimentan las tablas de la interfaz.
 * <p>
 * Se comparte por referencia entre todos los sub-controladores para que
 * todos trabajen siempre sobre el mismo estado "actual", incluso cuando
 * el CV completo se reemplaza (por ejemplo, al cargar un CV guardado).
 */
public class ContextoCV {

    private CurriculumVitae cv = new CurriculumVitae();

    private final ObservableList<ExperienciaLaboral> listaExp           = FXCollections.observableArrayList();
    private final ObservableList<FormacionAcademica> listaForm          = FXCollections.observableArrayList();
    private final ObservableList<Capacitacion>       listaCapacitacion  = FXCollections.observableArrayList();
    private final ObservableList<Habilidad>          listaHab           = FXCollections.observableArrayList();
    private final ObservableList<Idioma>             listaIdioma        = FXCollections.observableArrayList();

    public CurriculumVitae getCv()            { return cv; }
    public void setCv(CurriculumVitae cv)     { this.cv = cv; }

    public ObservableList<ExperienciaLaboral> getListaExp()          { return listaExp; }
    public ObservableList<FormacionAcademica> getListaForm()         { return listaForm; }
    public ObservableList<Capacitacion>       getListaCapacitacion() { return listaCapacitacion; }
    public ObservableList<Habilidad>          getListaHab()          { return listaHab; }
    public ObservableList<Idioma>             getListaIdioma()       { return listaIdioma; }

    /** Sustituye el CV actual por otro y sincroniza todas las listas observables con su contenido. */
    public void reemplazarCv(CurriculumVitae nuevoCv) {
        this.cv = nuevoCv;
        listaExp.setAll(nuevoCv.getExperiencias());
        listaForm.setAll(nuevoCv.getFormaciones());
        listaCapacitacion.setAll(nuevoCv.getCapacitaciones());
        listaHab.setAll(nuevoCv.getHabilidades());
        listaIdioma.setAll(nuevoCv.getIdiomas());
    }

    /** Vacía el CV actual y todas las listas observables (usado al crear un CV nuevo). */
    public void limpiar() {
        this.cv = new CurriculumVitae();
        listaExp.clear();
        listaForm.clear();
        listaCapacitacion.clear();
        listaHab.clear();
        listaIdioma.clear();
    }
}
