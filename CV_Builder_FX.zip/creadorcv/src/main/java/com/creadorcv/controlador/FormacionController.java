package com.creadorcv.controlador;

import com.creadorcv.modelo.FormacionAcademica;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador FXML del fragmento {@code PasoFormacion.fxml}.
 * Gestiona directamente sus propios controles y toda la lógica del bloque
 * "Formación Académica": configuración de la tabla y del combo de estado,
 * alta y baja de registros.
 */
public class FormacionController {

    @FXML private TextField txtInstitucion, txtTitulo, txtPeriodoInicioForm, txtPeriodoFinForm;
    @FXML private ComboBox<String> cmbEstado;
    @FXML private Button btnAgregarForm, btnEliminarForm;
    @FXML private TableView<FormacionAcademica> tblFormacion;
    @FXML private TableColumn<FormacionAcademica, String> colTitulo, colInstitucion, colEstado;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnAgregarForm.setOnAction(e -> agregar());
        btnEliminarForm.setOnAction(e -> eliminar());
    }

    public void configurarTabla() {
        colTitulo.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getTitulo()));
        colInstitucion.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getInstitucion()));
        colEstado.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getEstado()));
        tblFormacion.setItems(contexto.getListaForm());
    }

    public void configurarCombo() {
        cmbEstado.setItems(FXCollections.observableArrayList("Graduado", "En curso", "Incompleto"));
        cmbEstado.getSelectionModel().selectFirst();
    }

    public void agregar() {
        if (txtInstitucion.getText().trim().isEmpty() || txtTitulo.getText().trim().isEmpty()) {
            notificador.error("Institución y Título son obligatorios."); return;
        }
        FormacionAcademica form = new FormacionAcademica(
                txtInstitucion.getText().trim(), txtTitulo.getText().trim(),
                cmbEstado.getValue(), txtPeriodoInicioForm.getText().trim(),
                txtPeriodoFinForm.getText().trim());
        contexto.getListaForm().add(form);
        contexto.getCv().getFormaciones().add(form);
        txtInstitucion.clear(); txtTitulo.clear();
        txtPeriodoInicioForm.clear(); txtPeriodoFinForm.clear();
        notificador.setStatus("✔ Formación académica agregada.");
        actualizarPreview.run();
    }

    public void eliminar() {
        FormacionAcademica sel = tblFormacion.getSelectionModel().getSelectedItem();
        if (sel == null) { notificador.error("Selecciona una formación para eliminar."); return; }
        contexto.getListaForm().remove(sel);
        contexto.getCv().getFormaciones().remove(sel);
        notificador.setStatus("Formación eliminada.");
        actualizarPreview.run();
    }
}
