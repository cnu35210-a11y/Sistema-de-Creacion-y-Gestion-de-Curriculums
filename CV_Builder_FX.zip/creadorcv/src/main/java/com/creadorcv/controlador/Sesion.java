package com.creadorcv.controlador;

/**
 * Estado global de la aplicación mientras está abierta: usuario con la
 * sesión iniciada, el CV que se está editando y el nombre con el que
 * quedó guardado (null si todavía no se ha guardado nunca).
 */
public final class Sesion {

    private static final Sesion INSTANCIA = new Sesion();

    private String usuarioActual;
    private ContextoCV contexto = new ContextoCV();
    private String nombreArchivoActual; // null = CV nuevo, aún no guardado

    public static Sesion actual() { return INSTANCIA; }

    public String getUsuarioActual()                { return usuarioActual; }
    public void   setUsuarioActual(String usuario)   { this.usuarioActual = usuario; }

    public ContextoCV getContexto()                  { return contexto; }

    public String getNombreArchivoActual()           { return nombreArchivoActual; }
    public void   setNombreArchivoActual(String n)    { this.nombreArchivoActual = n; }

    /** Prepara el estado para editar un CV completamente nuevo. */
    public void iniciarCvNuevo() {
        contexto = new ContextoCV();
        nombreArchivoActual = null;
    }

    /** Cierra la sesión y limpia todo el estado en memoria. */
    public void cerrarSesion() {
        usuarioActual = null;
        contexto = new ContextoCV();
        nombreArchivoActual = null;
    }

    private Sesion() {}
}
