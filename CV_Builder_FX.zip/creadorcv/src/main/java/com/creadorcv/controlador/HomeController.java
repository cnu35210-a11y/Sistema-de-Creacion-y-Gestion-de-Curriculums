package com.creadorcv.controlador;

import com.creadorcv.modelo.CurriculumVitae;
import com.creadorcv.persistencia.RepositorioCV;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controla la pantalla de inicio: muestra los CVs guardados del usuario como
 * tarjetas con icono (estilo "tiles"), más una tarjeta especial con un "+"
 * para crear un currículum nuevo. Doble clic sobre una tarjeta la abre para
 * editar; un solo clic la selecciona y habilita el botón de eliminar.
 */
public class HomeController implements Initializable {

    @FXML private Label lblBienvenida;
    @FXML private FlowPane gridCurriculums;
    @FXML private Button btnEliminar;
    @FXML private Button btnCerrarSesion;
    @FXML private Label lblVacio;

    /** Tarjeta actualmente seleccionada (null si ninguna) y el nombre de CV que representa. */
    private VBox tarjetaSeleccionada;
    private String nombreSeleccionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblBienvenida.setText("Hola, " + Sesion.actual().getUsuarioActual());
        cargarLista();

        btnEliminar.setOnAction(e -> eliminarSeleccionado());

        btnCerrarSesion.setOnAction(e -> {
            Sesion.actual().cerrarSesion();
            Router.ir("Login.fxml");
        });
    }

    /** Reconstruye el grid completo: primero la tarjeta "+" y luego una tarjeta por cada CV guardado. */
    private void cargarLista() {
        tarjetaSeleccionada = null;
        nombreSeleccionado = null;
        btnEliminar.setDisable(true);

        gridCurriculums.getChildren().clear();
        gridCurriculums.getChildren().add(crearTarjetaNueva());

        List<String> nombres = RepositorioCV.listar(Sesion.actual().getUsuarioActual());
        for (String nombre : nombres) {
            gridCurriculums.getChildren().add(crearTarjetaCv(nombre));
        }

        lblVacio.setVisible(nombres.isEmpty());
        lblVacio.setManaged(nombres.isEmpty());
    }

    /** Tarjeta especial, siempre la primera, con un icono "+" para iniciar un currículum nuevo. */
    private VBox crearTarjetaNueva() {
        Circle circulo = new Circle(28);
        circulo.getStyleClass().add("new-tile-circle");

        Label mas = new Label("+");
        mas.getStyleClass().add("new-tile-plus");
        mas.setFont(Font.font(null, FontWeight.BOLD, 30));

        StackPane icono = new StackPane(circulo, mas);
        icono.setPrefSize(64, 64);

        Label texto = new Label("Nuevo\nCurrículum");
        texto.getStyleClass().add("new-tile-label");
        texto.setWrapText(true);
        texto.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        VBox tarjeta = new VBox(10, icono, texto);
        tarjeta.getStyleClass().addAll("cv-tile", "new-tile");
        tarjeta.setAlignment(javafx.geometry.Pos.CENTER);
        Tooltip.install(tarjeta, new Tooltip("Crear un currículum nuevo"));

        tarjeta.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                Sesion.actual().iniciarCvNuevo();
                Router.ir("Plantillas.fxml");
            }
        });
        return tarjeta;
    }

    /** Tarjeta con icono de "documento" que representa un CV guardado; un clic selecciona, doble clic abre. */
    private VBox crearTarjetaCv(String nombre) {
        StackPane icono = new StackPane(construirIconoDocumento());
        icono.setPrefSize(64, 72);

        Label texto = new Label(nombre);
        texto.getStyleClass().add("cv-tile-label");
        texto.setWrapText(true);
        texto.setMaxWidth(120);
        texto.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        texto.setTextOverrun(javafx.scene.control.OverrunStyle.ELLIPSIS);

        VBox tarjeta = new VBox(10, icono, texto);
        tarjeta.getStyleClass().add("cv-tile");
        tarjeta.setAlignment(javafx.geometry.Pos.CENTER);
        Tooltip.install(tarjeta, new Tooltip(nombre + "\nDoble clic para abrir y editar"));

        tarjeta.setOnMouseClicked(e -> {
            if (e.getButton() != MouseButton.PRIMARY) return;
            if (e.getClickCount() == 2) {
                abrirCv(nombre);
            } else {
                seleccionar(tarjeta, nombre);
            }
        });
        return tarjeta;
    }

    /** Dibuja un pequeño icono vectorial de "documento con esquina doblada" reutilizable en cada tarjeta. */
    private javafx.scene.Group construirIconoDocumento() {
        Rectangle hoja = new Rectangle(46, 58);
        hoja.setArcWidth(8);
        hoja.setArcHeight(8);
        hoja.setFill(Color.WHITE);
        hoja.getStyleClass().add("doc-icon-hoja");

        Polygon doblez = new Polygon(30, 0, 46, 16, 30, 16);
        doblez.getStyleClass().add("doc-icon-doblez");

        Region linea1 = crearLineaDocumento(28, 26);
        Region linea2 = crearLineaDocumento(28, 36);
        Region linea3 = crearLineaDocumento(20, 46);

        javafx.scene.Group grupo = new javafx.scene.Group(hoja, doblez, linea1, linea2, linea3);
        return grupo;
    }

    /** Crea una pequeña barra horizontal (simula una línea de texto), centrada dentro de la hoja de 46px de ancho. */
    private Region crearLineaDocumento(double ancho, double posicionY) {
        Region linea = new Region();
        linea.getStyleClass().add("doc-icon-linea");
        linea.setPrefSize(ancho, 4);
        linea.setMaxSize(ancho, 4);
        linea.setTranslateX((46 - ancho) / 2.0);
        linea.setTranslateY(posicionY);
        return linea;
    }

    /** Marca una tarjeta como seleccionada (y desmarca la anterior), habilitando el botón de eliminar. */
    private void seleccionar(VBox tarjeta, String nombre) {
        if (tarjetaSeleccionada != null) {
            tarjetaSeleccionada.getStyleClass().remove("cv-tile-selected");
        }
        tarjetaSeleccionada = tarjeta;
        nombreSeleccionado = nombre;
        tarjeta.getStyleClass().add("cv-tile-selected");
        btnEliminar.setDisable(false);
    }

    private void abrirCv(String nombre) {
        try {
            CurriculumVitae cv = RepositorioCV.cargar(Sesion.actual().getUsuarioActual(), nombre);
            Sesion.actual().getContexto().reemplazarCv(cv);
            Sesion.actual().setNombreArchivoActual(nombre);
            Router.ir("Formulario.fxml");
        } catch (IOException e) {
            lblVacio.setText("No se pudo abrir el CV: " + e.getMessage());
            lblVacio.setVisible(true);
            lblVacio.setManaged(true);
        }
    }

    private void eliminarSeleccionado() {
        if (nombreSeleccionado == null) return;

        Alert confirmacion = new Alert(AlertType.CONFIRMATION);
        confirmacion.setTitle("Eliminar currículum");
        confirmacion.setHeaderText("¿Eliminar \"" + nombreSeleccionado + "\"?");
        confirmacion.setContentText("Esta acción no se puede deshacer.");

        Optional<ButtonType> respuesta = confirmacion.showAndWait();
        if (respuesta.isPresent() && respuesta.get() == ButtonType.OK) {
            RepositorioCV.eliminar(Sesion.actual().getUsuarioActual(), nombreSeleccionado);
            cargarLista();
        }
    }
}
