package com.creadorcv.controlador;

import com.creadorcv.modelo.Idioma;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador FXML del fragmento {@code PasoIdiomas.fxml}.
 * Gestiona directamente sus propios controles y toda la lógica del bloque
 * "Idiomas": configuración de tabla y combo de nivel, alta y baja de
 * registros.
 */
public class IdiomaController {

    @FXML private TextField txtIdioma;
    @FXML private ComboBox<String> cmbNivelIdioma;
    @FXML private Button btnAgregarIdioma, btnEliminarIdioma;
    @FXML private TableView<Idioma> tblIdiomas;
    @FXML private TableColumn<Idioma, String> colIdioma, colNivelIdioma;

    private ContextoCV contexto;
    private NotificadorUI notificador;
    private Runnable actualizarPreview;

    /** Inyecta las dependencias compartidas y conecta los eventos de los botones. */
    public void inicializar(ContextoCV contexto, NotificadorUI notificador, Runnable actualizarPreview) {
        this.contexto = contexto;
        this.notificador = notificador;
        this.actualizarPreview = actualizarPreview;

        btnAgregarIdioma.setOnAction(e -> agregar());
        btnEliminarIdioma.setOnAction(e -> eliminar());
    }

    public void configurarTabla() {
        colIdioma.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNombre()));
        colNivelIdioma.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNivel()));
        tblIdiomas.setItems(contexto.getListaIdioma());
    }

    public void configurarCombo() {
        cmbNivelIdioma.setItems(FXCollections.observableArrayList("A1", "A2", "B1", "B2", "C1", "C2", "Nativo"));
        cmbNivelIdioma.getSelectionModel().selectFirst();
    }

    public void agregar() {
        if (txtIdioma.getText().trim().isEmpty()) { notificador.error("Ingresa el nombre del idioma."); return; }
        Idioma i = new Idioma(txtIdioma.getText().trim(), cmbNivelIdioma.getValue());
        contexto.getListaIdioma().add(i);
        contexto.getCv().getIdiomas().add(i);
        txtIdioma.clear();
        notificador.setStatus("✔ Idioma agregado.");
        actualizarPreview.run();
    }

    public void eliminar() {
        Idioma sel = tblIdiomas.getSelectionModel().getSelectedItem();
        if (sel == null) { notificador.error("Selecciona un idioma para eliminar."); return; }
        contexto.getListaIdioma().remove(sel);
        contexto.getCv().getIdiomas().remove(sel);
        notificador.setStatus("Idioma eliminado.");
        actualizarPreview.run();
    }
}
