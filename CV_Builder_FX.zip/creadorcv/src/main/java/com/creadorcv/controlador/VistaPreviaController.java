package com.creadorcv.controlador;

import com.creadorcv.persistencia.MotorExportacion;
import com.creadorcv.persistencia.RepositorioCV;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Optional;
import java.util.ResourceBundle;

/** Controla la vista previa final del CV: guardar, exportar a HTML, eliminar y volver al inicio. */
public class VistaPreviaController implements Initializable {

    @FXML private WebView webPreview;
    @FXML private Label lblEstado;
    @FXML private Button btnGuardar, btnExportarHtml, btnEliminar, btnVolver;

    private PreviewController preview;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        preview = new PreviewController(Sesion.actual().getContexto(), webPreview);
        preview.actualizarPreview();

        btnEliminar.setDisable(Sesion.actual().getNombreArchivoActual() == null);

        btnGuardar.setOnAction(e -> guardar());
        btnExportarHtml.setOnAction(e -> exportarHtml());
        btnEliminar.setOnAction(e -> eliminar());
        btnVolver.setOnAction(e -> Router.ir("Home.fxml"));
    }

    private void guardar() {
        String nombre = Sesion.actual().getNombreArchivoActual();
        if (nombre == null) {
            nombre = pedirNombreArchivo();
            if (nombre == null) return; // el usuario canceló
        }
        try {
            RepositorioCV.guardar(Sesion.actual().getUsuarioActual(), nombre, Sesion.actual().getContexto().getCv());
            Sesion.actual().setNombreArchivoActual(nombre);
            btnEliminar.setDisable(false);
            lblEstado.setText("✔ CV guardado como \"" + nombre + "\".");
        } catch (IOException e) {
            lblEstado.setText("No se pudo guardar el CV: " + e.getMessage());
        }
    }

    private String pedirNombreArchivo() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Guardar currículum");
        dialog.setHeaderText(null);
        dialog.setContentText("Nombre para este currículum:");
        Optional<String> resultado = dialog.showAndWait();
        if (resultado.isEmpty() || resultado.get().trim().isEmpty()) return null;
        return resultado.get().trim();
    }

    private void exportarHtml() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Exportar CV como HTML");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivo HTML (*.html)", "*.html"));
        String nombreBase = Sesion.actual().getContexto().getCv().getDatosPersonales().getNombre();
        fc.setInitialFileName("CV_" + (nombreBase != null ? nombreBase : "curriculum") + ".html");
        File file = fc.showSaveDialog(webPreview.getScene().getWindow());
        if (file == null) return;
        try {
            String html = MotorExportacion.generarHTML(Sesion.actual().getContexto().getCv());
            Files.write(file.toPath(), html.getBytes(StandardCharsets.UTF_8));
            lblEstado.setText("✔ Exportado a: " + file.getName());
        } catch (IOException e) {
            lblEstado.setText("No se pudo exportar: " + e.getMessage());
        }
    }

    private void eliminar() {
        String nombre = Sesion.actual().getNombreArchivoActual();
        if (nombre == null) return;

        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar el currículum \"" + nombre + "\"? Esta acción no se puede deshacer.");
        confirmacion.setHeaderText(null);
        confirmacion.setTitle("Confirmar eliminación");
        Optional<ButtonType> resultado = confirmacion.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            RepositorioCV.eliminar(Sesion.actual().getUsuarioActual(), nombre);
            Router.ir("Home.fxml");
        }
    }
}
