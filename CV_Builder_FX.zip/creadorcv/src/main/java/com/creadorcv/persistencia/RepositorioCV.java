package com.creadorcv.persistencia;

import com.creadorcv.modelo.CurriculumVitae;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Gestiona los currículums guardados de cada usuario en disco, dentro de
 * "mis_cvs/&lt;usuario&gt;/&lt;nombre&gt;.json". Cada usuario tiene su propia carpeta.
 */
public class RepositorioCV {

    private static final String CARPETA_BASE = "mis_cvs";

    public static File carpetaUsuario(String usuario) {
        File carpeta = new File(CARPETA_BASE, usuario);
        if (!carpeta.exists()) carpeta.mkdirs();
        return carpeta;
    }

    /** Lista los nombres (sin extensión) de los CVs guardados por el usuario, alfabéticamente. */
    public static List<String> listar(String usuario) {
        File[] archivos = carpetaUsuario(usuario).listFiles((dir, name) -> name.endsWith(".json"));
        List<String> nombres = new ArrayList<>();
        if (archivos != null) {
            Arrays.sort(archivos, Comparator.comparing(File::getName));
            for (File f : archivos) nombres.add(f.getName().replace(".json", ""));
        }
        return nombres;
    }

    public static boolean existe(String usuario, String nombre) {
        return archivo(usuario, nombre).exists();
    }

    public static void guardar(String usuario, String nombre, CurriculumVitae cv) throws IOException {
        GestorJSON.guardar(cv, archivo(usuario, nombre));
    }

    public static CurriculumVitae cargar(String usuario, String nombre) throws IOException {
        return GestorJSON.cargar(archivo(usuario, nombre));
    }

    public static boolean eliminar(String usuario, String nombre) {
        return archivo(usuario, nombre).delete();
    }

    private static File archivo(String usuario, String nombre) {
        return new File(carpetaUsuario(usuario), nombre + ".json");
    }

    private RepositorioCV() {}
}
