package com.creadorcv.persistencia.plantillas;

import com.creadorcv.modelo.*;

import java.util.List;

import static com.creadorcv.persistencia.plantillas.HtmlUtil.esc;
import static com.creadorcv.persistencia.plantillas.HtmlUtil.ne;

/** Plantilla "Con Foto": foto circular + datos arriba, contenido en dos columnas. */
public final class PlantillaFoto {

    public static String generar(CurriculumVitae cv) {
        DatosPersonales dp = cv.getDatosPersonales();
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>")
          .append("<style>")
          .append("*{margin:0;padding:0;box-sizing:border-box;}")
          .append("body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#222;padding:32px 40px;}")
          .append(".cabecera{display:flex;align-items:center;gap:24px;border-bottom:1px solid #ccc;padding-bottom:18px;margin-bottom:18px;}")
          .append(".cabecera img{width:110px;height:110px;border-radius:50%;object-fit:cover;border:3px solid #444;}")
          .append(".foto-placeholder{width:110px;height:110px;border-radius:50%;background:#e9ecef;display:flex;align-items:center;justify-content:center;color:#adb5bd;font-size:12px;border:3px solid #444;}")
          .append(".cabecera h1{font-size:26px;font-weight:normal;text-transform:uppercase;letter-spacing:1px;}")
          .append(".contacto-linea{margin-top:8px;font-size:12px;color:#444;line-height:1.9;}")
          .append(".perfil-txt{font-size:12.5px;color:#444;line-height:1.6;margin-bottom:6px;}")
          .append(".cols{display:grid;grid-template-columns:220px 1fr;gap:28px;}")
          .append("h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#222;border-bottom:2px solid #444;padding-bottom:4px;margin:16px 0 8px;}")
          .append(".col-izq h2, .col-izq h3{margin-top:14px;}")
          .append(".entry{margin-bottom:12px;}")
          .append(".entry-title{font-weight:bold;font-size:12.5px;}")
          .append(".entry-sub{color:#555;font-size:12px;}")
          .append(".entry-date{color:#888;font-size:11px;margin-bottom:3px;}")
          .append(".entry-desc{font-size:12px;color:#444;line-height:1.55;}")
          .append("ul.simple{list-style:none;padding:0;}")
          .append("ul.simple li{font-size:12px;color:#333;padding:3px 0;border-bottom:1px dashed #ddd;}")
          .append("</style></head><body>")
          .append("<div class='cabecera'>");

        String dataURI = dp.getFotoDataURI();
        if (dataURI != null) sb.append("<img src='").append(dataURI).append("' alt='Foto de perfil'/>");
        else sb.append("<div class='foto-placeholder'>Sin foto</div>");

        sb.append("<div><h1>").append(esc(dp.getNombreCompleto())).append("</h1><div class='contacto-linea'>");
        if (ne(dp.getDireccion()))         sb.append("📍 ").append(esc(dp.getDireccion())).append("<br>");
        if (ne(dp.getTelefono()))          sb.append("📞 ").append(esc(dp.getTelefono())).append(" &nbsp; ");
        if (ne(dp.getCorreo()))            sb.append("✉ ").append(esc(dp.getCorreo()));
        if (ne(dp.getEnlaceProfesional())) sb.append("<br>🔗 ").append(esc(dp.getEnlaceProfesional()));
        sb.append("</div></div></div>");

        if (ne(dp.getPerfilProfesional())) {
            sb.append("<p class='perfil-txt'>").append(esc(dp.getPerfilProfesional())).append("</p>");
        }

        sb.append("<div class='cols'><div class='col-izq'>");

        List<FormacionAcademica> forms = cv.getFormaciones();
        if (!forms.isEmpty()) {
            sb.append("<h2>Educación</h2>");
            for (FormacionAcademica f : forms) {
                sb.append("<div class='entry'><div class='entry-title'>").append(esc(f.getTitulo())).append("</div>")
                  .append("<div class='entry-sub'>").append(esc(f.getInstitucion())).append("</div></div>");
            }
        }

        List<Habilidad> habs = cv.getHabilidades();
        if (!habs.isEmpty()) {
            sb.append("<h2>Habilidades</h2><ul class='simple'>");
            for (Habilidad h : habs) sb.append("<li>").append(esc(h.getNombre())).append("</li>");
            sb.append("</ul>");
        }

        List<Idioma> ids = cv.getIdiomas();
        if (!ids.isEmpty()) {
            sb.append("<h2>Idiomas</h2><ul class='simple'>");
            for (Idioma i : ids) sb.append("<li>").append(esc(i.getNombre())).append(" – ").append(esc(i.getNivel())).append("</li>");
            sb.append("</ul>");
        }

        sb.append("</div><div class='col-der'>");

        List<ExperienciaLaboral> exps = cv.getExperiencias();
        if (!exps.isEmpty()) {
            sb.append("<h2>Experiencia Laboral</h2>");
            for (ExperienciaLaboral e : exps) {
                sb.append("<div class='entry'>")
                  .append("<div class='entry-title'>").append(esc(e.getPuesto())).append("</div>")
                  .append("<div class='entry-sub'>").append(esc(e.getEmpresa())).append("</div>")
                  .append("<div class='entry-date'>").append(esc(e.getFechaInicio())).append(" – ")
                  .append(e.isTrabajoActual() ? "Actualidad" : esc(e.getFechaFin())).append("</div>");
                if (ne(e.getLogros()))
                    sb.append("<div class='entry-desc'>").append(esc(e.getLogros()).replace("\n", "<br>")).append("</div>");
                sb.append("</div>");
            }
        }

        List<Capacitacion> caps = cv.getCapacitaciones();
        if (!caps.isEmpty()) {
            sb.append("<h2>Capacitaciones</h2><ul class='simple'>");
            for (Capacitacion c : caps) {
                sb.append("<li>").append(esc(c.getNombre()));
                if (ne(c.getInstitucion())) sb.append(" (").append(esc(c.getInstitucion())).append(")");
                sb.append("</li>");
            }
            sb.append("</ul>");
        }

        sb.append("</div></div></body></html>");
        return sb.toString();
    }

    private PlantillaFoto() {}
}
