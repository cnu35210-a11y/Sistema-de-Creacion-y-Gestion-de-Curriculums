package com.creadorcv.persistencia;

import com.creadorcv.modelo.CurriculumVitae;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * Gestiona la serialización / deserialización del CV a archivos JSON.
 * Utiliza la librería Gson con formato Pretty-Print para legibilidad.
 */
public class GestorJSON {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .serializeNulls()
            .create();

    /**
     * Guarda el CV en la ruta indicada.
     * @param cv   Objeto raíz a serializar
     * @param file Archivo destino (.json)
     * @throws IOException Si no se puede escribir el archivo
     */
    public static void guardar(CurriculumVitae cv, File file) throws IOException {
        try (Writer writer = new OutputStreamWriter(
                new FileOutputStream(file), StandardCharsets.UTF_8)) {
            GSON.toJson(cv, writer);
        }
    }

    /**
     * Carga un CV desde un archivo JSON.
     * @param file Archivo fuente (.json)
     * @return     Objeto CurriculumVitae deserializado
     * @throws IOException Si no se puede leer el archivo
     */
    public static CurriculumVitae cargar(File file) throws IOException {
        try (Reader reader = new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8)) {
            return GSON.fromJson(reader, CurriculumVitae.class);
        }
    }
}
