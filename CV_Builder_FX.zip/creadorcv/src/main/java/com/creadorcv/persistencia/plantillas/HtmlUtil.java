package com.creadorcv.persistencia.plantillas;

/** Utilidades compartidas por las plantillas HTML: escape y validación de texto. */
public final class HtmlUtil {

    private HtmlUtil() {}

    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    /** true si el texto no es nulo ni está vacío (tras recortar espacios). */
    public static boolean ne(String s) {
        return s != null && !s.trim().isEmpty();
    }
}
