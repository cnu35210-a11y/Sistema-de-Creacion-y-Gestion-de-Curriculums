package com.creadorcv.persistencia.plantillas;

import com.creadorcv.modelo.*;

import java.util.List;

import static com.creadorcv.persistencia.plantillas.HtmlUtil.esc;
import static com.creadorcv.persistencia.plantillas.HtmlUtil.ne;

/** Plantilla "ATS Simple": minimalista, sin fotografía, una sola columna, apta para lectores ATS. */
public final class PlantillaATS {

    public static String generar(CurriculumVitae cv) {
        DatosPersonales dp = cv.getDatosPersonales();
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>")
          .append("<style>")
          .append("*{margin:0;padding:0;box-sizing:border-box;}")
          .append("body{font-family:Georgia,'Times New Roman',serif;font-size:13px;color:#1a1a1a;padding:36px 44px;}")
          .append(".cabecera{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #1a1a1a;padding-bottom:14px;margin-bottom:16px;}")
          .append(".cabecera h1{font-size:26px;letter-spacing:1px;font-weight:normal;text-transform:uppercase;}")
          .append(".contacto{text-align:right;font-size:11.5px;color:#333;line-height:1.7;font-family:Arial,sans-serif;}")
          .append("h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid #999;padding-bottom:3px;margin:18px 0 8px;font-family:Arial,sans-serif;}")
          .append(".perfil-txt{font-size:12.5px;line-height:1.6;color:#333;font-family:Arial,sans-serif;}")
          .append(".entry{margin-bottom:10px;font-family:Arial,sans-serif;}")
          .append(".entry-linea1{font-size:12.5px;}")
          .append(".entry-linea1 b{font-weight:bold;}")
          .append(".entry-dur{color:#555;font-size:11.5px;}")
          .append("ul{margin:3px 0 0 18px;padding:0;}")
          .append("li{font-size:12px;color:#333;line-height:1.55;}")
          .append(".dos-col{display:flex;gap:30px;}")
          .append(".dos-col ul{flex:1;}")
          .append("</style></head><body>")
          .append("<div class='cabecera'><h1>").append(esc(dp.getNombreCompleto())).append("</h1>")
          .append("<div class='contacto'>");
        if (ne(dp.getDireccion()))         sb.append(esc(dp.getDireccion())).append("<br>");
        if (ne(dp.getTelefono()))          sb.append(esc(dp.getTelefono())).append("<br>");
        if (ne(dp.getCorreo()))            sb.append(esc(dp.getCorreo())).append("<br>");
        if (ne(dp.getEnlaceProfesional())) sb.append(esc(dp.getEnlaceProfesional()));
        sb.append("</div></div>");

        if (ne(dp.getPerfilProfesional())) {
            sb.append("<h2>Perfil Profesional</h2>")
              .append("<p class='perfil-txt'>").append(esc(dp.getPerfilProfesional())).append("</p>");
        }

        List<FormacionAcademica> forms = cv.getFormaciones();
        if (!forms.isEmpty()) {
            sb.append("<h2>Formación Académica</h2>");
            for (FormacionAcademica f : forms) {
                sb.append("<div class='entry entry-linea1'><b>").append(esc(f.getTitulo())).append("</b> / ")
                  .append(esc(f.getInstitucion()));
                if (ne(f.getPeriodoInicio()) || ne(f.getPeriodoFin()))
                    sb.append(" <span class='entry-dur'>(").append(esc(f.getPeriodoInicio())).append(" – ")
                      .append(esc(f.getPeriodoFin())).append(")</span>");
                sb.append("</div>");
            }
        }

        List<ExperienciaLaboral> exps = cv.getExperiencias();
        if (!exps.isEmpty()) {
            sb.append("<h2>Experiencia Laboral</h2>");
            for (ExperienciaLaboral e : exps) {
                sb.append("<div class='entry'><div class='entry-linea1'><b>").append(esc(e.getEmpresa()))
                  .append("</b> / ").append(esc(e.getPuesto())).append(" <span class='entry-dur'>/ ")
                  .append(esc(e.getFechaInicio())).append(" – ")
                  .append(e.isTrabajoActual() ? "Actualidad" : esc(e.getFechaFin())).append("</span></div>");
                if (ne(e.getLogros())) {
                    sb.append("<ul>");
                    for (String linea : e.getLogros().split("\n"))
                        if (ne(linea)) sb.append("<li>").append(esc(linea.trim())).append("</li>");
                    sb.append("</ul>");
                }
                sb.append("</div>");
            }
        }

        List<Capacitacion> caps = cv.getCapacitaciones();
        if (!caps.isEmpty()) {
            sb.append("<h2>Capacitaciones</h2><ul>");
            for (Capacitacion c : caps) {
                sb.append("<li>").append(esc(c.getNombre()));
                if (ne(c.getInstitucion())) sb.append(" (").append(esc(c.getInstitucion())).append(")");
                sb.append("</li>");
            }
            sb.append("</ul>");
        }

        List<Habilidad> habs = cv.getHabilidades();
        if (!habs.isEmpty()) {
            sb.append("<h2>Habilidades</h2><div class='dos-col'>").append(columnasHabilidades(habs)).append("</div>");
        }

        List<Idioma> ids = cv.getIdiomas();
        if (!ids.isEmpty()) {
            sb.append("<h2>Idiomas</h2><ul>");
            for (Idioma i : ids) sb.append("<li>").append(esc(i.getNombre())).append(" — ").append(esc(i.getNivel())).append("</li>");
            sb.append("</ul>");
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    /** Reparte las habilidades en dos columnas de viñetas, como en el CV de referencia. */
    private static String columnasHabilidades(List<Habilidad> habs) {
        int mitad = (habs.size() + 1) / 2;
        StringBuilder izq = new StringBuilder("<ul>");
        StringBuilder der = new StringBuilder("<ul>");
        for (int i = 0; i < habs.size(); i++) {
            String li = "<li>" + esc(habs.get(i).getNombre()) + "</li>";
            if (i < mitad) izq.append(li); else der.append(li);
        }
        izq.append("</ul>");
        der.append("</ul>");
        return izq.toString() + der.toString();
    }

    private PlantillaATS() {}
}
