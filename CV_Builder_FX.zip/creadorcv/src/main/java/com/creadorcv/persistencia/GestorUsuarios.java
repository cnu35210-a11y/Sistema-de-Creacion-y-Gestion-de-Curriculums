package com.creadorcv.persistencia;

import com.creadorcv.modelo.Usuario;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestiona el registro e inicio de sesión de usuarios locales.
 * Las cuentas se guardan en "usuarios.json" en la raíz del proyecto,
 * con la contraseña cifrada mediante SHA-256 (nunca en texto plano).
 */
public class GestorUsuarios {

    private static final File ARCHIVO = new File("usuarios.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TIPO_LISTA = new TypeToken<List<Usuario>>() {}.getType();

    public static boolean existeUsuario(String usuario) {
        return buscar(usuario) != null;
    }

    /** Registra un usuario nuevo. Devuelve false si el nombre ya existe. */
    public static boolean registrar(String usuario, String password) throws IOException {
        List<Usuario> lista = cargarTodos();
        if (buscarEn(lista, usuario) != null) return false;
        lista.add(new Usuario(usuario, hash(password)));
        guardarTodos(lista);
        return true;
    }

    /** Valida credenciales. Devuelve true si el usuario existe y la contraseña coincide. */
    public static boolean validar(String usuario, String password) {
        Usuario u = buscar(usuario);
        return u != null && u.getPasswordHash().equals(hash(password));
    }

    private static Usuario buscar(String usuario) {
        try {
            return buscarEn(cargarTodos(), usuario);
        } catch (IOException e) {
            return null;
        }
    }

    private static Usuario buscarEn(List<Usuario> lista, String usuario) {
        for (Usuario u : lista) {
            if (u.getUsuario().equalsIgnoreCase(usuario)) return u;
        }
        return null;
    }

    private static List<Usuario> cargarTodos() throws IOException {
        if (!ARCHIVO.exists()) return new ArrayList<>();
        try (Reader r = new InputStreamReader(new FileInputStream(ARCHIVO), StandardCharsets.UTF_8)) {
            List<Usuario> lista = GSON.fromJson(r, TIPO_LISTA);
            return lista != null ? lista : new ArrayList<>();
        }
    }

    private static void guardarTodos(List<Usuario> lista) throws IOException {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(ARCHIVO), StandardCharsets.UTF_8)) {
            GSON.toJson(lista, TIPO_LISTA, w);
        }
    }

    private static String hash(String texto) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(texto.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e); // SHA-256 siempre está disponible en la JVM
        }
    }

    private GestorUsuarios() {}
}
