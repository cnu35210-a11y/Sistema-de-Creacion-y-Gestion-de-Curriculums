package com.creadorcv.persistencia.plantillas;

import com.creadorcv.modelo.*;

import java.util.List;

import static com.creadorcv.persistencia.plantillas.HtmlUtil.esc;
import static com.creadorcv.persistencia.plantillas.HtmlUtil.ne;

/** Plantilla "Clásico Ejecutivo": barra lateral oscura + contenido en blanco. */
public final class PlantillaClasica {

    public static String generar(CurriculumVitae cv) {
        DatosPersonales dp = cv.getDatosPersonales();
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>")
          .append("<style>")
          .append("*{margin:0;padding:0;box-sizing:border-box;}")
          .append("body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;color:#222;display:flex;min-height:100vh;}")
          .append(".sidebar{width:220px;background:#2c3e50;color:#ecf0f1;padding:28px 18px;flex-shrink:0;}")
          .append(".foto-wrap{text-align:center;margin-bottom:16px;}")
          .append(".foto-wrap img{width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid #3498db;}")
          .append(".foto-placeholder{width:100px;height:100px;border-radius:50%;background:#34495e;display:inline-flex;align-items:center;justify-content:center;color:#7f8c8d;font-size:12px;border:3px solid #3498db;}")
          .append(".sidebar h1{font-size:18px;line-height:1.3;margin-bottom:4px;}")
          .append(".sidebar h3{font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#95a5a6;margin:18px 0 8px;border-bottom:1px solid #34495e;padding-bottom:4px;}")
          .append(".sidebar p,.sidebar a{font-size:12px;color:#ecf0f1;word-break:break-all;line-height:1.8;text-decoration:none;}")
          .append(".tag{display:inline-block;background:#34495e;color:#ecf0f1;border-radius:3px;padding:3px 9px;font-size:11px;margin:2px 3px 2px 0;}")
          .append(".main{flex:1;padding:28px 32px;background:#fff;}")
          .append(".main h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#2c3e50;border-bottom:2px solid #3498db;padding-bottom:5px;margin:22px 0 12px;}")
          .append(".entry{margin-bottom:14px;}")
          .append(".entry-title{font-weight:bold;font-size:13px;}")
          .append(".entry-sub{color:#555;font-size:12px;}")
          .append(".entry-date{color:#888;font-size:11px;margin-bottom:4px;}")
          .append(".entry-desc{font-size:12px;color:#444;line-height:1.6;}")
          .append(".perfil-txt{font-size:13px;color:#444;line-height:1.7;margin-bottom:6px;}")
          .append("</style></head><body>")
          .append("<div class='sidebar'><div class='foto-wrap'>");

        String dataURI = dp.getFotoDataURI();
        if (dataURI != null) sb.append("<img src='").append(dataURI).append("' alt='Foto de perfil'/>");
        else sb.append("<div class='foto-placeholder'>Sin foto</div>");
        sb.append("</div><h1>").append(esc(dp.getNombreCompleto())).append("</h1>");

        sb.append("<h3>Contacto</h3>");
        if (ne(dp.getCorreo()))            sb.append("<p>✉ ").append(esc(dp.getCorreo())).append("</p>");
        if (ne(dp.getTelefono()))          sb.append("<p>📞 ").append(esc(dp.getTelefono())).append("</p>");
        if (ne(dp.getDireccion()))         sb.append("<p>📍 ").append(esc(dp.getDireccion())).append("</p>");
        if (ne(dp.getEnlaceProfesional())) sb.append("<p><a href='").append(esc(dp.getEnlaceProfesional()))
                                             .append("'>").append(esc(dp.getEnlaceProfesional())).append("</a></p>");

        List<FormacionAcademica> forms = cv.getFormaciones();
        if (!forms.isEmpty()) {
            sb.append("<h3>Educación</h3>");
            for (FormacionAcademica f : forms) {
                sb.append("<p><b>").append(esc(f.getTitulo())).append("</b><br>")
                  .append(esc(f.getInstitucion())).append("</p>");
            }
        }

        List<Habilidad> habs = cv.getHabilidades();
        if (!habs.isEmpty()) {
            sb.append("<h3>Habilidades</h3><div>");
            for (Habilidad h : habs) sb.append("<span class='tag'>").append(esc(h.getNombre())).append("</span>");
            sb.append("</div>");
        }

        List<Idioma> ids = cv.getIdiomas();
        if (!ids.isEmpty()) {
            sb.append("<h3>Idiomas</h3>");
            for (Idioma i : ids) sb.append("<p>").append(esc(i.getNombre())).append(" – ").append(esc(i.getNivel())).append("</p>");
        }

        sb.append("</div>"); // fin sidebar
        sb.append("<div class='main'>");

        if (ne(dp.getPerfilProfesional())) {
            sb.append("<h2>Perfil Profesional</h2>")
              .append("<p class='perfil-txt'>").append(esc(dp.getPerfilProfesional())).append("</p>");
        }

        List<ExperienciaLaboral> exps = cv.getExperiencias();
        if (!exps.isEmpty()) {
            sb.append("<h2>Experiencia Laboral</h2>");
            for (ExperienciaLaboral e : exps) {
                sb.append("<div class='entry'>")
                  .append("<div class='entry-title'>").append(esc(e.getPuesto())).append("</div>")
                  .append("<div class='entry-sub'>").append(esc(e.getEmpresa())).append("</div>")
                  .append("<div class='entry-date'>").append(esc(e.getFechaInicio())).append(" – ")
                  .append(e.isTrabajoActual() ? "Actualidad" : esc(e.getFechaFin())).append("</div>");
                if (ne(e.getLogros()))
                    sb.append("<div class='entry-desc'>").append(esc(e.getLogros()).replace("\n", "<br>")).append("</div>");
                sb.append("</div>");
            }
        }

        List<Capacitacion> caps = cv.getCapacitaciones();
        if (!caps.isEmpty()) {
            sb.append("<h2>Capacitaciones</h2><div class='entry'>");
            for (Capacitacion c : caps) {
                sb.append("<div class='entry-desc'>• ").append(esc(c.getNombre()));
                if (ne(c.getInstitucion())) sb.append(" (").append(esc(c.getInstitucion())).append(")");
                sb.append("</div>");
            }
            sb.append("</div>");
        }

        sb.append("</div></body></html>");
        return sb.toString();
    }

    private PlantillaClasica() {}
}
