package com.creadorcv.persistencia;

import com.creadorcv.modelo.CurriculumVitae;
import com.creadorcv.persistencia.plantillas.PlantillaATS;
import com.creadorcv.persistencia.plantillas.PlantillaClasica;
import com.creadorcv.persistencia.plantillas.PlantillaFoto;

/**
 * Punto de entrada para generar el HTML del CV: delega en la clase de
 * plantilla correspondiente según cv.getPlantilla() ("CLASICO" | "ATS" | "FOTO").
 */
public class MotorExportacion {

    public static String generarHTML(CurriculumVitae cv) {
        String plantilla = cv.getPlantilla();
        if ("ATS".equals(plantilla))  return PlantillaATS.generar(cv);
        if ("FOTO".equals(plantilla)) return PlantillaFoto.generar(cv);
        return PlantillaClasica.generar(cv);
    }

    private MotorExportacion() {}
}
